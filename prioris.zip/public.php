<?php
    include 'header.php';
?>
    <h1>Prioris tesztfeladat - public</h1>
    

<?php
    include 'footer.php';
?>